package com.example.exercise

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.exercise.databinding.ActivitySelectedBinding

class SelectedActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySelectedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelectedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val selected = intent.getStringArrayExtra("selectedExercises")
        binding.selectedTextView.text = "선택된 운동:\n" + selected?.joinToString("\n")
    }
}
