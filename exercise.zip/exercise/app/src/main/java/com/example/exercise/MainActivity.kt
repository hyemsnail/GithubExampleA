package com.example.exercise

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.exercise.databinding.ActivityMainBinding
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ExerciseAdapter
    private lateinit var originalList: List<Exercise>
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 원본 데이터
        originalList = listOf(
            Exercise("푸쉬업", "상체"),
            Exercise("숄더 프레스", "상체"),
            Exercise("숄더 탭", "상체"),
            Exercise("스쿼트", "하체"),
            Exercise("런지", "하체"),
            Exercise("힙 브릿지", "하체"),
            Exercise("크런치", "복근"),
            Exercise("플랭크", "복근"),
            Exercise("레그 레이즈", "복근")
        )

        adapter = ExerciseAdapter(originalList) { exercise, isChecked ->
            exercise.isSelected = isChecked
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        // ✅ 검색 기능 (TextWatcher)
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                searchJob?.cancel()
                searchJob = CoroutineScope(Dispatchers.Main).launch {
                    delay(300)
                    val query = s?.toString()?.lowercase()?.trim() ?: ""
                    val filtered = originalList.filter { ex ->
                        ex.name.lowercase().contains(query)
                    }
                    adapter.updateList(filtered)
                }
            }
        })

        // ✅ 선택한 운동 보기
        binding.nextButton.setOnClickListener {
            val selected = originalList.filter { it.isSelected }.map { it.name }
            val intent = Intent(this, SelectedActivity::class.java)
            intent.putExtra("selectedExercises", selected.toTypedArray())
            startActivity(intent)
        }
    }
}
