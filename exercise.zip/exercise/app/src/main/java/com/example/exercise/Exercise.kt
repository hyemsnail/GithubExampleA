package com.example.exercise

data class Exercise(
    val name: String,
    val category: String,
    var isSelected: Boolean = false
)
